#!/bin/bash

#Script to cleanup excess PDFLaTeX files

rm *.aux

rm *.log


