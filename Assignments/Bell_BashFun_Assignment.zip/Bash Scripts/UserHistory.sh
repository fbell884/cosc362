
#!/bin/bash

history

echo ""

date 

history > history.txt

echo ""

echo "Script Ran: " >> history.txt

date >> history.txt


