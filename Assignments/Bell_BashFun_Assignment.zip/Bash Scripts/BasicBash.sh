#!/bin/bash

#Basic For Loop

names='Alice Bob Carol Doug Ed Fred George'
for name in $names
do 
echo $name
done
echo done


