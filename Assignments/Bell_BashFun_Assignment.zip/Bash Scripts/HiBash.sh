#!/bin/bash

echo "Here is 'Hi' in ASCII Stickmen"
echo ""

echo "  o         o      o     "
sleep 1
echo " <|>       <|>   _<|>_   "
sleep 1
echo " < >       < >           "
sleep 1
echo "  |         |      o     "
sleep 1
echo "  o__/_ _\__o     <|>    "
sleep 1
echo "  |         |     / \    "
sleep 1
echo " <o>       <o>    \o/    "
sleep 1
echo "  |         |      |     "
sleep 1
echo " / \       / \    / \    "

sleep 2
clear
echo "I hope you enjoyed!"
sleep 2
clear
                      
                      
                      
