#!/bin/bash

last > loginhistory.txt

